import React from 'react';
import './StudentModule.css';
import StudentView from './StudentView';
import EditModel from './EditModel';
import axios from 'axios';


const StudentModule= ({studentid,email,first_name,last_name,gender,dob,config})=>{
const [showStudentView, setShowStudentView] = React.useState(false);

const [showEdit, setShowEdit]= React.useState(false)

const [studentData, setStudentData] = React.useState({});

function getStudentView(){
  setShowStudentView(true)
}
 
function closeStudentView(){
  setShowStudentView(false)
}

const handleEdit = ()=> {
  setShowEdit(true)
}

const handleDelete = () =>{
           axios.delete(`http://localhost:3000/students/${studentid}`, config)
                   .then(response =>{
                    alert('Student deleted sucessfully:', response.data);
                    window.location.reload()
                   })
                   .catch(error =>{
                    alert('Error deleting student:', error)
                   });
                   
};

React.useEffect(() =>{
  const fetchData = async () => {

 try{
      const response =
      await axios.get(`http://localhost:3000/students/${studentid}`,config);
      setStudentData(response.data.data)
    }catch(error){
      alert(error)
    }

  };
  fetchData()
}, [studentid,config])


return(
    <div className="studentinfo">
    <p>{studentid}</p>
    <p>{email}</p>
    <p>{first_name}</p>
    <p>{last_name}</p>
    <p>{gender}</p>
    <p>{dob}</p>
    <div>
         <button className="edit" onClick={handleEdit}>edit</button>
         <button className="view" onClick={getStudentView} >view</button>

    <button className="delete" onClick={handleDelete}> delete</button>
</div>
      
{showStudentView && <StudentView closeStudentView={closeStudentView} student={studentData} />}
{showEdit && <EditModel  setShowEdit={setShowEdit}
                         studentid={studentid}
                         firstname ={first_name}
                         lastname={last_name}
                         email={email}
                         gender={gender}
                         dob={dob}
                         config={config}
                         
/>} 


    </div>
  );
};
export default StudentModule;