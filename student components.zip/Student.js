import React from "react";
import './Student.css'
import StudentModule from "./StudentModule";
import StudentForm from "./StudentForm";
import axios from 'axios';

const Student = ({config}) =>{
    
   const headerName = 'Student';

const [studentData,setStudentData] = React.useState([]);

React.useEffect(() => {
  const fetchStudents = async () => {
    try {
      const response = await axios.get('http://localhost:3000/students', config);
      setStudentData(response.data.data);
    } catch (error) {
      alert(error)
    } 
  };


  fetchStudents();
}, [config]);

   
const hasStudents = studentData.length > 0;

   let studentModule = hasStudents && (
     studentData.map((student) => (
       <StudentModule
         key={student.student_id}
         studentid={student.student_id}
         studentemail={student.email}
         studentfirstname={student.first_name}
         studentlastname={student.last_name}
         studentgender={student.gender}
         studentdob={student.dob}
         studentdepartmentid={student.department_id}
        config={config}
       />
     ))
   );

const [showStudent,setShowStudent] = React.useState(false)

 function getStudentForm(){
       setShowStudent(true);
 }

 function closeStudentForm(){
  setShowStudent(false);
 }

//  function handleAddStudent(newStudentName) {
//   // Generate a unique ID for the new student
//   const newStudentid = Math.max(...studentData.map((dept) => dept.studentid)) + 1;

//   setStudentData((prevData) => [
//     ...prevData,
//     { studentid: newStudentid, studentName: newStudentName },
//   ]);
//   setShowStudent(false); // Close the form after adding
//  }

 
return(
        <div className="studentcontent">
                    <div className="header-student">
                        <h2>{headerName}</h2>
                        <p>Student In School</p>
                    </div>
                    <button className="assignstudentbutton" 
                    onClick={getStudentForm}>
                    Create Student</button>


<div className="studentmain">
            <div className="studentheader">
            <p>StudentID</p>
                <p>email</p>
                <p>first_name</p>
                <p>last_name</p>
                <p>gender</p>
                <p>dob</p>
                <p>departmentid</p>
             <p className="action">Action</p>
            </div>
            {hasStudents ? (
          studentModule
        ) : (
          <p>No students found.</p>
        )}
      
 </div>

{ showStudent && <StudentForm
closeStudentForm = {closeStudentForm}
config={config}
/>  }

 </div>
    );
};

export default Student;